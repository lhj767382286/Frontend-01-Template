# es6

ECMAScript® 2016 语言规范 中文版 
 
# 在线文档 
 
http://zhoushengfe.com/es6/es6-ch.html  

# 相关文章：

ECMAScript6词法： http://www.cnblogs.com/mufc-go/p/7886527.html
 
 
